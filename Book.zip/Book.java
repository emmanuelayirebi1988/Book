//Book.java

public class Book {
    String title;
    boolean borrowed;
    private void rented(){

    }

    // Creates a new Book
    public Book(String bookTitle) {
        // Implement this method
    }

    // Marks the book as rented
    public void borrowed(){
        // Implement this method
    }

    // Marks the book as not rented
    public void returned(){
        // Implement this method
    }

    // Returns true if the book is rented, false otherwise
    public boolean isBorrowed() {
        return borrowed;
        // Implement this method
    }

    // Returns the title of the book
    public String getTitle(){
        return title;
        // implement this method
    }

    public static void main(String[] args) {
        // Small test of the Book class
        Book example = new Book("The Da Vinci code");

        System.out.println("Title should be the Da vinci code): " + example.getTitle());
        System.out.println("Borrowed? (should be false):" + example.isBorrowed());
        example.rented();

        System.out.println("Borrowed? (should be true): " + example.isBorrowed());
        example.returned();

        System.out.println("Borrowed? (should be false): " + example.isBorrowed());


    }

    // Library.java

    public static class Library{

        public Library(String s) {
        }
        // Add the missing implementation to this class

        public static void main(String[] args){

            // Create two libraries
            Library firstLibrary = new Library("10 Main St.");
            Library secondLibrary = new Library("228 Liberty St.");

            // Add four books to the first library
            firstLibrary.addBook(new Book("The Da Vinci code"));
            firstLibrary.addBook(new Book("La Petit prince"));
            firstLibrary.addBook(new Book("A Tale of Two Cities"));
            firstLibrary.addBook(new Book("The Lord of the Rings"));

            // print opening hours and the addresses
            System.out.println("Library hours:");
            printOpeningHours();
            System.out.println();
            System.out.println("Library addresses:");
            firstLibrary.printAddress();
            secondLibrary.printAddress();
            System.out.println();

            // Try to borrow The Lords of the Rings from both libraries
            System.out.println("Borrowing The Lord of the Rings:");
            firstLibrary.borrowBook("The Lord of the Rings");
            firstLibrary.borrowBook("The Lord of the Rings");
            secondLibrary.borrowBook("The Lord of the Rings");
            System.out.println();

            // Print the titles of all available books from libraries
            System.out.println("Books available in the first library:");
            firstLibrary.printAvilableBooks();
            System.out.println();
            System.out.println("Books Available in the second library:");
            secondLibrary.printAvailableBooks();
            System.out.println();

            // Return The Lords of the Rings to the first library
            System.out.println("Returning The Lord of the Rings:");
            firstLibrary.returnBook("The Lord of the Rings");
            System.out.println();

            // Print the titles of available from the first library
            System.out.println("Books available in the first library:");
            firstLibrary.printAvailableBooks();
        }

        private void returnBook(String the_lord_of_the_rings) {
        }

        private void printAvailableBooks() {
        }

        private void printAvilableBooks() {
        }

        private void borrowBook(String the_lord_of_the_rings) {
        }

        private void printAddress() {
        }

        private static void printOpeningHours() {
        }

        private void addBook(Book the_da_vinci_code) {
        }
    }
}
